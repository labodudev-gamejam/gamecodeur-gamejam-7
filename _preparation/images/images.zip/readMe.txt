T�te: Rond => Selection => R�duire de 2 px, bordure 2 px, noir
Pareille pour tous les autres �l�ments